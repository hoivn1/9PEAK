"use client";

/**
 * Auto Mode tab — lifted from profile/page.js Auto Routing card.
 * [9pix-fork] v0.4.1 — Smart Routing v2 dedicated page.
 */

import PropTypes from "prop-types";
import { Card, Button, Toggle, PlanBadge } from "@/shared/components";

const TIER_META = {
  pro: { label: "Pro", strategy: "fill-first" },
  business: { label: "Business", strategy: "fill-first" },
  enterprise: { label: "Enterprise", strategy: "fill-first" },
  team: { label: "Team", strategy: "fill-first" },
  plus: { label: "Plus", strategy: "round-robin (sticky 2)" },
  go: { label: "Go", strategy: "round-robin (sticky 2)" },
  free: { label: "Free", strategy: "round-robin (last resort)" },
  other: { label: "Other / Unknown", strategy: "round-robin" },
};
const TIER_ORDER = ["pro", "business", "enterprise", "team", "plus", "go", "free", "other"];

function normalizeTier(planType) {
  if (!planType || typeof planType !== "string") return "other";
  const lower = planType.toLowerCase().trim();
  const stripped = lower.replace(/^(chatgpt|plan|tier)\s+/i, "").trim();
  const known = ["enterprise", "business", "team", "plus", "free", "pro", "go"];
  for (const tier of known) {
    if (stripped === tier || stripped.includes(tier)) return tier;
  }
  return "other";
}

export default function AutoTab({ settings, codexConnections, onUpdateMode }) {
  const autoOn = (settings.routingMode || "custom") === "auto";

  const groups = (() => {
    const buckets = {};
    for (const t of TIER_ORDER) buckets[t] = [];
    for (const conn of codexConnections) {
      const tier = normalizeTier(conn.providerSpecificData?.chatgptPlanType);
      (buckets[tier] || buckets.other).push(conn);
    }
    return TIER_ORDER.filter((t) => buckets[t].length > 0).map((t) => ({
      tier: t,
      meta: TIER_META[t],
      connections: buckets[t],
    }));
  })();

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <span className="material-symbols-outlined text-[20px]">auto_awesome</span>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Auto Mode</h3>
              <p className="text-sm text-text-muted">
                Tự động xoay theo plan ChatGPT — khuyến nghị cho hầu hết user
              </p>
            </div>
          </div>
          <Toggle checked={autoOn} onChange={() => onUpdateMode(autoOn ? "custom" : "auto")} />
        </div>

        <div className="flex flex-col gap-3 pt-2 border-t border-border/50">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
            <div className="p-3 rounded-lg bg-bg border border-border">
              <p className="font-medium mb-1">Tier cao (Pro / Business / Team)</p>
              <p className="text-text-muted text-xs">
                Fill-first — vắt 1 acc trước, chỉ chuyển khi rate-limit. Tận dụng quota cao.
              </p>
            </div>
            <div className="p-3 rounded-lg bg-bg border border-border">
              <p className="font-medium mb-1">Tier thấp (Plus / Go)</p>
              <p className="text-text-muted text-xs">
                Round-robin sticky=2 — rải đều mỗi 2 request, tránh burn quota nhỏ.
              </p>
            </div>
          </div>

          <div className="pt-2 border-t border-border/50">
            <p className="text-sm font-medium mb-2">Bản đồ rotation hiện tại</p>
            {groups.length === 0 ? (
              <p className="text-sm text-text-muted italic">
                Chưa có Codex connection active. Vào trang Providers → Codex để thêm acc.
              </p>
            ) : (
              <div className="flex flex-col gap-2">
                {groups.map(({ tier, meta, connections }) => (
                  <div
                    key={tier}
                    className="flex items-center justify-between p-3 rounded-lg bg-bg border border-border"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <PlanBadge planType={meta.label} size="md" />
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">
                          {connections.length} acc · {meta.strategy}
                        </p>
                        <p className="text-xs text-text-muted truncate">
                          {connections
                            .map((c) => c.displayName || c.email || c.name || c.id?.slice(0, 8))
                            .join(", ")}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </Card>

      {!autoOn && (
        <div className="p-3 rounded-md bg-amber-500/10 border border-amber-500/30 text-sm text-amber-700 dark:text-amber-300">
          Auto Mode đang TẮT — đang dùng routing thủ công. Bật Auto lại bằng toggle ở trên,
          hoặc qua tab Preset / Advanced để chọn strategy khác.
        </div>
      )}
    </div>
  );
}

AutoTab.propTypes = {
  settings: PropTypes.object.isRequired,
  codexConnections: PropTypes.array.isRequired,
  onUpdateMode: PropTypes.func.isRequired,
};
